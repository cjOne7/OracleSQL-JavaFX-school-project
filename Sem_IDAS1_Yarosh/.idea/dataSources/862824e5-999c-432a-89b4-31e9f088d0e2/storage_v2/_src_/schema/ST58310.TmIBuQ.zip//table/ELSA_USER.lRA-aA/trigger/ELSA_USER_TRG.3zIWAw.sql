create trigger ELSA_USER_TRG
    before insert
    on ELSA_USER
    for each row
BEGIN
  <<COLUMN_SEQUENCES>>
  BEGIN
    NULL;
  END COLUMN_SEQUENCES;
END;
/

